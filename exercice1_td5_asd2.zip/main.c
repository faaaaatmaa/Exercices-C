/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void chercherVal(int tab[], int n, int A, int*pos, int*nb_occ){
    *pos=-1;
    *nb_occ=0;
    for(int i=0; i<n; i++){
        if( tab[i]==A){
            *nb_occ=*nb_occ + 1;
            *pos= i;
        }
    }
}
int main() {
    int tableau[] = {945, 3, 7, 3, 889, 53};
    int taille = 6;
    int valeur = 3;
    int position, nb_occurences;

    chercherVal(tableau, taille, valeur, &position, &nb_occurences);

    printf("Dernière position de %d : %d\n", valeur, position);
    printf("Nombre d'occurrences de %d : %d\n", valeur, nb_occurences);

    return 0;
}

