/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
int main() {
    char ch[100];
    char c;
    char *p;
    printf("Entrez une chaîne de caractères : ");
    fgets(ch, sizeof(ch), stdin);
    ch[strcspn(ch, "\n")] = '\0';
    printf("Entrez un caractère à chercher : ");
    scanf(" %c", &c); 
    p= strchr(ch, c);
    if (p != NULL) {
        printf("La chaîne à partir du caractère '%c' est : %s\n", c, p);
    } 
    else {
        printf("Le caractère '%c' n'a pas été trouvé dans la chaîne.\n", c);
    }

    return 0;
}
