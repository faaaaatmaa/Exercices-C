/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int Fibaconni(int n){
    if ((n==0)||(n==1)){
        return n;
    }
    else{
        return Fibaconni(n-1)+Fibaconni(n-2);
    }
}
int main()
{
    int x;
    printf("donner un entier");
    scanf("%d",&x);
    printf("%d",Fibaconni(x));

    return 0;
}