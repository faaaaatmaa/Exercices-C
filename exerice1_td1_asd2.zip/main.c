/******************************************************************************

Welcome to GDB Online.
  GDB online is n online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void lire(int M[10][10],int l,int c){
    for(int i=0;i<l;i++){
        for(int j=0;j<c;j++){
            printf("M[%d][%d]=",i,j);
            scanf("%d",&M[i][j]);
        }
    }
}
int somme(int M[10][10],int l,int c){
    int s=0;
    for(int i=0;i<l;i++){
        for(int j=0;j<c;j++){
            if(M[i][j]!=0){
                s+=M[i][j];
            }
        }
    }
    return s;
}
float moyenne(int M[10][10],int l,int c){
    return (float)somme(M, l, c) / (l * c);
}
int produit(int M[10][10],int l, int c){
    int p=1;
    for(int i=0;i<l;i++){
        for(int j=0;j<c;j++){
            if(M[i][j]!=0){
                p=p*M[i][j];
            }
        }
    }
    return p;
}
void chercher(int M[10][10],int l,int c,int x){
    int test=0;
    int i=0;
    while(i<l && !test){
        int j=0;
        while(j<c && !test){
            test=M[i][j]==x;
            j++;
        }
        i++;
    }
    if(test==1){
        printf("%d existe dans la matrice ",x);
    }
    else{
        printf("%d n'existe pas dans la matrice ",x);
    }
}

int main() {
    int M[10][10];  // Maximum size of the matrix is 10x10
    int l, c, x;
    
    // Input number of rows and columns
    printf("Entrez le nombre de lignes: ");
    scanf("%d", &l);
    printf("Entrez le nombre de colonnes: ");
    scanf("%d", &c);

    // Read matrix values
    lire(M, l, c);

    // Sum of the matrix
    int sum = somme(M, l, c);
    printf("La somme des éléments non nuls est: %d\n", sum);

    // Average of the matrix
    float avg = moyenne(M, l, c);
    printf("La moyenne des éléments est: %.2f\n", avg);

    // Product of the matrix
    int product = produit(M, l, c);
    printf("Le produit des éléments non nuls est: %d\n", product);

    // Search for an element in the matrix
    printf("Entrez l'élément à chercher: ");
    scanf("%d", &x);
    chercher(M, l, c, x);

    return 0;
}