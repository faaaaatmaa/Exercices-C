/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
typedef struct{
    int heures;
    int minutes;
    int secondes;
    int millisecondes;
} Temps;
double convertir_en_secondes(Temps t) {
    return t.heures* 3600 + t.minutes* 60 + t.secondes+ t.millisecondes/ 1000.0;
}
void saisir_temps(Temps *t) {
    printf("Entrez l'heure (hh:mm:ss.xxx) : ");
    scanf("%d %d %d %d", &t->heures, &t->minutes, &t->secondes, &t->millisecondes);
}
int main() {
    Temps t1, t2;
    double difference;
    // Saisie des deux mesures de temps
    printf("Première mesure\n");
    saisir_temps(&t1);
    printf("Deuxième mesure\n");
    saisir_temps(&t2);
    // Calcul de la différence
    difference= convertir_en_secondes(t2) -convertir_en_secondes(t1);
    // Affichage du résultat
    printf("Il y a %.3f seconde(s) de différence.\n", difference);  
    return 0;
}