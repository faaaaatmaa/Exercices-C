/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define MAX_LINE_LENGTH 80

int main() {
    FILE *file;
    char line[MAX_LINE_LENGTH + 1]; 
    int lineNumber = 1;
    file = fopen("fichier.txt", "r");
    if (file == NULL) {
        printf("Impossible d'ouvrir le fichier.\n");
        return 1;
    }
    printf("Contenu du fichier :\n");
    while (fgets(line, MAX_LINE_LENGTH + 1, file) != NULL) {
        printf("%3d: %s", lineNumber, line);
        lineNumber++;
    }
    fclose(file);
    return 0;
}