/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>
typedef struct{
    int jour;
    int mois;
    int annee;
}Date;
typedef struct{
    char nom[50];
    char prenom[50];
    Date naissance;
}Etudiant;
int verif(Etudiant e1,Etudiant e2){
    return((strcmp(e1.nom,e2.nom)==0) && (strcmp(e1.prenom,e2.prenom)==0) && e1.naissance.jour==e2.naissance.jour && e1.naissance.mois==e2.naissance.mois && e1.naissance.annee==e2.naissance.annee);
}
void saisir(Etudiant *e){
    printf("Nom : ");
    scanf("%s",e->nom);
    printf("Prénom : ");
    scanf("%s",e->prenom);
    printf("Date de naissance(jj mm aaaa) : ");
    scanf("%d %d %d",&e->naissance.jour,&e->naissance.mois,&e->naissance.annee);
}
int main()
{
    Etudiant E1, E2;
    printf("donner les informations du premier etudiant ");
    saisir(&E1);
    printf("donner les informations du deuxiéme etudiant ");
    saisir(&E2);
    if (verif(E1,E2)){
        printf("\n Les deux etudiants sont identiques. \n");
    }
    else{
        printf("\n Les deux etudiants ne sont pas identiques. \n");
    }

    return 0;
}