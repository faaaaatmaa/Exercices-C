/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
#define Taille 50
typedef struct Personne{
    char nom[Taille];
    char prenom[Taille];
    int age;
}Personne;
void saisir_Personne(Personne*p){
    printf("Nom: ");
    scanf("%s",p->nom);
    printf("Prenom: ");
    scanf("%s",p->prenom);
    printf("Age: ");
    scanf("%d",&p->age);
}

int main()
{
    Personne p1, p2, p3;
    saisir_Personne(&p1);
    saisir_Personne(&p2);
    if(p1.age>p2.age){
        p3=p2;
    }
    else{
        p3=p1;
    }
    printf("La personne la moin agée est: %s \t %s",p3.nom,p3.prenom);

    return 0;
}
