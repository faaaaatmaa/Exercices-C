/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int division(int m){
    if(m>=1){
        return (1+division(m-2));
    }
}
int main()
{
    int n;
    printf("donner un entier ");
    scanf("%d",&n);
    printf("%d",division(n));

    return 0;
}
