/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include "stdio.h"
#include "conio.h"
//declaration structetudiant
typedef struct 
{
    int num_E; 
    char nom[20];
    char prenom[20];
}Etudiant;
void main()
{
    Etudiant *pte, E; 
    pte =&E;
    printf("donner le numero de l'etudiant");
    scanf("%d", &pte->num_E); 
    printf("donner le nom de l'etudiant\n"); 
    scanf("%s", pte->nom);
    printf("donner le prenom de l'etudiant\n");
    scanf("%s", pte->prenom); 
    printf("%d %s %s", E.num_E, E.nom, E.prenom);
    getch(); }