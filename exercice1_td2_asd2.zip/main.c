/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int Guess (int x, int y)
{
    if (x == y) return x; else
    {
        if (x > y)
            return Guess (x-1, y) + Guess (x, y+1); 
        else
            return Guess (x+1, y) + Guess (x, y-1);
    }
}
int main()
{
    printf("%d \n",Guess(3,1));
    printf("%d \n",Guess(4,2));
    printf("%d \n",Guess(2,5));
    printf("%d ",Guess(3,6));
    return 0;
}