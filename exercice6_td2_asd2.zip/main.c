/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int palindrome(char *ch){
    int e;
    e=strlen(ch);
    if (e<=1){
        return 1;
    }
    else{
        if (ch[0]!=ch[e-1]){
            return 0;
        }
        else{
            char*dest=malloc(sizeof(char)*(e-2));
            dest[e-1]='\0';
            memcpy(dest,ch+1,e-2);
            return palindrome(dest);
        }
    }
}
int main()
{
    printf("Hello World");

    return 0;
}
