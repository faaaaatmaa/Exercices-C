/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
static int factRecNT(int n){
    int r;
    if (n > 1){
        r=factRecNT(n-1);
        r=r*n;
    }
    else{
        r=1;}
    return r;
}
int main() {
    int num = 4;
    printf("Factorial of %d is %d\n", num, factRecNT(num));
    return 0;
}