/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void Binaire(int n)
{
    if (n>0){
        Binaire (n/2);
        printf("%d",n%2);
    }
}
int main()
{
    int x;
    printf("donner un entier ");
    scanf("%d",&x);
    Binaire(x);

    return 0;
}